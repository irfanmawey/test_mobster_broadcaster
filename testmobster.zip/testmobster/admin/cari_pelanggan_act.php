<?php 
$cari=$_GET['cari'];
header("location:pelanggan.php?cari=$cari");
?>