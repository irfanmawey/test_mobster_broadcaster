<?php 
include 'header.php';
?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Detail Pelanggan</h3>
<a class="btn" href="pelanggan.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>

<?php
$pelanggan_id=mysql_real_escape_string($_GET['pelanggan_id']);


$det=mysql_query("select * from pelanggan where pelanggan_id='$pelanggan_id'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
	?>					
	<table class="table">
		<tr>
			<td>Nama Pelanggan</td>
			<td><?php echo $d['nama'] ?></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><?php echo $d['email'] ?></td>
		</tr>
		<tr>
			<td>Nomor WhatsApp</td>
			<td><?php echo $d['no_wa'] ?></td>
		</tr>
	</table>
	<?php 
}
?>
<?php include 'footer.php'; ?>