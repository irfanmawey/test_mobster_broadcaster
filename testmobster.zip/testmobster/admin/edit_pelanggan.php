<?php 
include 'header.php';
?>
<h3><span class="glyphicon glyphicon-briefcase"></span>  Edit Pelanggan</h3>
<a class="btn" href="pelanggan.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_pelanggan=mysql_real_escape_string($_GET['pelanggan_id']);
$det=mysql_query("select * from pelanggan where pelanggan_id='$id_pelanggan'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="update_pelanggan.php" method="post">
		<table class="table">
			<tr>
				<td></td>
				<td><input type="hidden" name="pelanggan_id" value="<?php echo $d['pelanggan_id'] ?>"></td>
			</tr>
			<tr>
				<td>Nama Pelanggan</td>
				<td><input type="text" class="form-control" name="nama" value="<?php echo $d['nama'] ?>"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" class="form-control" name="email" value="<?php echo $d['email'] ?>"></td>
			</tr>
			<tr>
				<td>Nomor WhatsApp</td>
				<td><input type="text" class="form-control" name="no_wa" value="<?php echo $d['no_wa'] ?>"></td>
			</tr>
			
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>
<?php include 'footer.php'; ?>