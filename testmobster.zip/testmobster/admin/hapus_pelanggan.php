<?php 
include 'config.php';
$pelanggan_id=$_GET['pelanggan_id'];
mysql_query("delete from pelanggan where pelanggan_id='$pelanggan_id'");
header("location:pelanggan.php");

?>