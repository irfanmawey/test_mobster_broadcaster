<?php include 'header.php'; ?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Data Pelanggan</h3>
<button style="margin-bottom:20px" data-toggle="modal" data-target="#myModal" class="btn btn-info col-md-2"><span class="glyphicon glyphicon-plus"></span>Input Data Pelanggan</button>
<br/>
<br/>

<?php 
$per_hal=10;
$jumlah_record=mysql_query("SELECT COUNT(*) from pelanggan");
$jum=mysql_result($jumlah_record, 0);
$halaman=ceil($jum / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>
<div class="col-md-12">
	<table class="col-md-2">
		<tr>
			<td>Jumlah Record</td>		
			<td><?php echo $jum; ?></td>
		</tr>
		<tr>
			<td>Jumlah Halaman</td>	
			<td><?php echo $halaman; ?></td>
		</tr>
	</table>
	<!-- <a style="margin-bottom:10px" href="lap_pelanggan.php" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
 --></div>
<form action="cari_pelanggan_act.php" method="get">
	<div class="input-group col-md-5 col-md-offset-7">
		<span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-search"></span></span>
		<input type="text" class="form-control" placeholder="Cari Pelanggan di sini .." aria-describedby="basic-addon1" name="cari">	
	</div>
</form>
<br/>
<table class="table table-bordered table-striped table-hover">
	<tr>
		<th class="col-md-1">No</th>
		<th class="col-md-2">Pelanggan ID</th>
		<th class="col-md-2">Nama Pelanggan</th>
		<th class="col-md-2">Email</th>
		<th class="col-md-2">Nomor WhatsApp</th>
		<!-- <th class="col-md-1">Sisa</th>		 -->
		<th class="col-md-4">Opsi</th>
	</tr>
	<?php 
	if(isset($_GET['cari'])){
		$cari=mysql_real_escape_string($_GET['cari']);
		$psn=mysql_query("select * from pelanggan where nama like '$cari' or pelanggan_id like '$cari'");
	}else{
		$psn=mysql_query("select * from pelanggan limit $start, $per_hal");
	}
	$no=1;
	while($b=mysql_fetch_array($psn)){

		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $b['pelanggan_id'] ?></td>
			<td><?php echo $b['nama'] ?></td>
			<td><?php echo $b['email'] ?></td>
			<td><?php echo $b['no_wa'] ?></td>


			<td>
				<a href="det_pelanggan.php?pelanggan_id=<?php echo $b['pelanggan_id']; ?>" class="btn btn-info">Detail</a>
				<a href="edit_pelanggan.php?pelanggan_id=<?php echo $b['pelanggan_id']; ?>" class="btn btn-warning">Edit</a>
				<a onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ location.href='hapus_pelanggan.php?pelanggan_id=<?php echo $b['pelanggan_id']; ?>' }" class="btn btn-danger">Hapus</a>
			</td>
		</tr>		
		<?php 
	}
	?>
</table>
<ul class="pagination">			
			<?php 
			for($x=1;$x<=$halaman;$x++){
				?>
				<li><a href="?page=<?php echo $x ?>"><?php echo $x ?></a></li>
				<?php
			}
			?>						
		</ul>
<!-- modal input -->
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Pelanggan Baru</h4>
			</div>
			<div class="modal-body">
				<form action="tmb_pelanggan_act.php" method="post">
					<div class="form-group">
						<label>Pelanggan ID</label>
						<input name="pelanggan_id" type="text" class="form-control" placeholder="Pelanggan ID .." required="Harap isi Field ini">
					</div>
					<div class="form-group">
						<label>Nama Pelanggan</label>
						<input name="nama" type="text" class="form-control" placeholder="Nama Pelanggan .." required="Harap isi Field ini">
					</div>
					<div class="form-group">
						<label>Email</label>
						<input name="email" type="text" class="form-control" placeholder="Email .." required="Harap isi Field ini">
					</div>
					<div class="form-group">
						<label>Nomor WhatsApp</label>
						<input name="no_wa" type="text" class="form-control" placeholder="Nomor WhatsApp .." required="Harap isi Field ini">
					</div>													

				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			</form>
		</div>
	</div>
</div>


<div class="col-md-14">
	<table class="col-md-10">
		<tr>
			<td>Catatan : Untuk Broadcast pesan ke seluruh database pelanggan dengan Post Request,saya sudah mencari dan mencoba  menggunakan CURL, namun basic nya saya masih kurang paham, mohon di jadikan bahan pertimbangan, saya yakin saya bisa lebih baik untuk ke depan nya. terima kasih</td>	



<?php 
include 'footer.php';

?>