<?php 
include 'config.php';
$pelanggan_id=$_POST['pelanggan_id'];
$nama=$_POST['nama'];
$email=$_POST['email'];
$no_wa=$_POST['no_wa'];

mysql_query("insert into pelanggan values('$pelanggan_id','$nama','$email','$no_wa')");
header("location:pelanggan.php");

 ?>