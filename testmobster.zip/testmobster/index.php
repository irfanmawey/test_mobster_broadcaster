<html lang="en">
<?php include('admin/config.php'); ?>
<b><a class="btn btn-info btn-xl js-scroll-trigger" href="index.php">Back to Home</a> <br><b>
<form action="login_act.php" method="POST">

					
							<style type="text/css">
    #body-form {
        width:400px;
        margin:0 auto;
        margin-top:150px;
        border: 1px solid #0e90d2;
        text-align: center;
        background: #fff;
        box-shadow: 2px 2px 2px #999;
    }
    #title-form {
        width:100%;
        background:#0e90d2;
        margin:0;
        padding:10px 0;
        font-size: 16px;
        color: #fff;
    }
    .row {width:100%;margin-bottom:5px}
    .row:last-child {margin:0}
    form {padding:10px}
    form input {padding:10px; width: 90%}
    input[name="submit-btn"]{width: 20%;background-color: #0e90d2;border:none;color:#fff}
</style>
<div id="body-form">
<h2 id="title-form">
Login Admin</h2>
<form>
<div class="row">
<tr>
								<h2><b>Username</b></td> <td><input type="text" name="uname" height="15"></h2>
							</tr>
							<tr>
								<h2><b>Password</b></td> <td><input type="password" name="pass"></h2>
							</tr>
							<tr>
<td align="right" colspan="2">
									<h2><input type="submit" value="login" name="login"></h2>
								

</div>
</form>
</div>

					
						
					
					
					
</form>
<?php
if (!empty($_GET['error'])) {
	if ($_GET['error'] == 1) {
		?>
        <script language="javascript">
		alert('Username dan Password belum diisi!');
		</script>
        <?php
	} else if ($_GET['error'] == 2) {
		?>
        <script language="javascript">
		alert('Username belum diisi!');
		</script>
        <?php
	} else if ($_GET['error'] == 3) {
		?>
        <script language="javascript">
		alert('Password belum diisi!');
		</script>
        <?php
	} else if ($_GET['error'] == 4) {
		?>
        <script language="javascript">
		alert('Username dan Password tidak terdaftar!');
		</script>
        <?php	
	}
}
?>
</body>
</html>
