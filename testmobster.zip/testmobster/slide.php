<!DOCTYPE HTML>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<html lang="en">
<head>
    <title>Nivo Slider Demo</title>
    
    <link rel="stylesheet" href="style/style.css" type="text/css" />
    <style type="text/css">body {background-color:#2f2f2f;}</style>

</head>
<body>

<div id="slider-wrapper">
    <div id="slider" class="nivoSlider">
        <a href="#"><img src="images/1.jpg" alt="" title="Aku tidak akan pernah tahu" /></a>
        <a href="#"><img src="images/2.jpg" alt="" title="Bahwa ini dan mereka itu tidak akan pernah identik" /></a>
        <a href="#"><img src="images/3.jpg" alt="" title="Sebuah kenyataan yang lucu" /></a>
        <a href="#"><img src="images/4.jpg" alt="" title="Meski seringkali begitu menyakitkan" /></a>
    </div>
</div>
        
    <script type="text/javascript" src="scripts/jquery-1.6.1.min.js"></script>
    <script type="text/javascript" src="scripts/jquery.nivo.slider.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider({
            pauseTime: 5000,
            startSlide: 3
        });
    });
    </script>
</body>
</html>